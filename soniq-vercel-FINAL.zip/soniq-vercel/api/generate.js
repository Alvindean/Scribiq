/**
 * SONIQ — Anthropic API Proxy
 * POST /api/generate
 * Keeps your API key server-side, adds basic rate limiting.
 */

// In-memory anon rate limit (resets on cold start — good enough for launch)
const anonUsage = new Map();

function checkAnonLimit(ip) {
  const now = Date.now();
  const entry = anonUsage.get(ip);
  if (!entry || (now - entry.reset) > 60 * 60 * 1000) {
    anonUsage.set(ip, { count: 1, reset: now });
    return { allowed: true, used: 1, limit: 5 };
  }
  if (entry.count >= 5) {
    return { allowed: false, used: entry.count, limit: 5 };
  }
  entry.count++;
  return { allowed: true, used: entry.count, limit: 5 };
}

module.exports = async function handler(req, res) {
  // CORS
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  // API key check
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return res.status(500).json({
      error: 'ANTHROPIC_API_KEY is not set. Go to Vercel → your project → Settings → Environment Variables and add it.'
    });
  }

  // Rate limit unauthenticated requests by IP
  const ip = (req.headers['x-forwarded-for'] || '').split(',')[0].trim() || 'unknown';
  const usage = checkAnonLimit(ip);
  if (!usage.allowed) {
    return res.status(429).json({
      error: 'Hourly limit reached',
      message: 'You have used 5 free generations this hour. Come back later or deploy with Supabase for accounts.',
      upgrade: true
    });
  }

  // Parse body
  let body;
  try {
    body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
  } catch {
    return res.status(400).json({ error: 'Invalid JSON in request body' });
  }

  const { messages, system, max_tokens = 4096 } = body || {};
  if (!messages || !Array.isArray(messages) || messages.length === 0) {
    return res.status(400).json({ error: 'messages array is required' });
  }

  // Call Anthropic
  try {
    const payload = {
      model: 'claude-sonnet-4-20250514',
      max_tokens: Math.min(max_tokens, 4096),
      messages,
    };
    if (system) payload.system = system;

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      const errText = await response.text();
      console.error('Anthropic error:', response.status, errText);
      return res.status(response.status).json({
        error: `Anthropic API error ${response.status}`,
        detail: errText,
      });
    }

    const data = await response.json();
    res.setHeader('X-Usage-Used', usage.used);
    res.setHeader('X-Usage-Limit', usage.limit);
    return res.status(200).json(data);

  } catch (err) {
    console.error('SONIQ proxy error:', err);
    return res.status(500).json({ error: 'Internal server error', detail: err.message });
  }
};
