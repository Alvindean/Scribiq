-- ============================================================
-- SONIQ — Supabase Database Schema
-- Run this entire file in: Supabase → SQL Editor → New Query
-- ============================================================

-- ── USER PROFILES ───────────────────────────────────────────
-- Extends Supabase's built-in auth.users table
CREATE TABLE IF NOT EXISTS user_profiles (
  id                    UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email                 TEXT NOT NULL,
  plan                  TEXT NOT NULL DEFAULT 'free' CHECK (plan IN ('free', 'pro', 'studio')),
  songs_this_month      INTEGER NOT NULL DEFAULT 0,
  billing_period_start  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  stripe_customer_id    TEXT,
  stripe_subscription_id TEXT,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at            TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── SONGS (cloud library) ────────────────────────────────────
CREATE TABLE IF NOT EXISTS songs (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title       TEXT NOT NULL DEFAULT 'Untitled',
  genre       TEXT,
  topic       TEXT,
  lyrics      TEXT,
  style       TEXT,       -- Suno style prompt
  structure   TEXT,       -- structure map
  dopamine    TEXT,       -- dopamine analysis
  notes       TEXT,       -- writer notes
  is_public   BOOLEAN NOT NULL DEFAULT FALSE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── INDEXES ──────────────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_songs_user_id ON songs(user_id);
CREATE INDEX IF NOT EXISTS idx_songs_created_at ON songs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_user_profiles_plan ON user_profiles(plan);

-- ── ROW LEVEL SECURITY ───────────────────────────────────────
-- Users can only see and edit their own data

ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE songs ENABLE ROW LEVEL SECURITY;

-- user_profiles: users can read/update their own row
CREATE POLICY "Users can view own profile"
  ON user_profiles FOR SELECT
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON user_profiles FOR UPDATE
  USING (auth.uid() = id);

-- songs: users can CRUD their own songs
CREATE POLICY "Users can view own songs"
  ON songs FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own songs"
  ON songs FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own songs"
  ON songs FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own songs"
  ON songs FOR DELETE
  USING (auth.uid() = user_id);

-- Public songs are visible to everyone (for future community feed)
CREATE POLICY "Public songs are viewable by all"
  ON songs FOR SELECT
  USING (is_public = TRUE);

-- ── AUTO-CREATE PROFILE ON SIGNUP ────────────────────────────
-- This trigger fires when a new user signs up, creating their profile row automatically
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO user_profiles (id, email)
  VALUES (NEW.id, NEW.email)
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- ── UPDATED_AT AUTO-UPDATE ────────────────────────────────────
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER songs_updated_at
  BEFORE UPDATE ON songs
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER profiles_updated_at
  BEFORE UPDATE ON user_profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ============================================================
-- Done! Your schema is ready.
-- Next: set these env vars in Vercel:
--   SUPABASE_URL            → Settings → API → Project URL
--   SUPABASE_ANON_KEY       → Settings → API → anon public
--   SUPABASE_SERVICE_ROLE_KEY → Settings → API → service_role (keep secret)
--   APP_URL                 → your Vercel domain e.g. https://soniq.vercel.app
--   ANTHROPIC_API_KEY       → console.anthropic.com
-- ============================================================
